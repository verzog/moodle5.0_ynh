# All available README files by language

- [Read the README in English](README.md)
- [Lea el README en español](README_es.md)
- [Irakurri README euskaraz](README_eu.md)
- [Lire le README en français](README_fr.md)
- [Le o README en galego](README_gl.md)
- [Baca README dalam bahasa bahasa Indonesia](README_id.md)
- [Lees de README in het Nederlands](README_nl.md)
- [Przeczytaj README w języku polski](README_pl.md)
- [Прочитать README на русский](README_ru.md)
- [阅读中文（简体）的 README](README_zh_Hans.md)
